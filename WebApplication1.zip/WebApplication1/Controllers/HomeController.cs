﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;
using Microsoft.AspNet.Identity;
using System.IO;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {

        Utility utility;
        ApplicationDbContext db;


        string accountName = "emsstorageforfile";
        string accountKey = "jxmY5OAuJKtRY0VnJJeQqS3aXZSCLAQEym/JlkEFlViixq5FbsVSKM5n7J9li+fQYKU8CmHW8Ori9NG9neE9AQ==";
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public ActionResult ImageUpload()
        {

            ViewBag.Message = "Image Upload Demo";
            string loggedInUserId = User.Identity.GetUserId();
            List<Image> userImages = (from r in db.Images where r.UserId == loggedInUserId select r).ToList();
            ViewBag.PhotoCount = userImages.Count;
            return View(userImages);
        }
        [HttpPost]
        public ActionResult UploadImage(HttpPostedFileBase file)
        {
            if (file != null)
            {
                //replace "container" with the name of your Blob container
                string ContainerName = "container"; //hardcoded container name. 
                file = file ?? Request.Files["file"];
                string fileName = Path.GetFileName(file.FileName);
                Stream imageStream = file.InputStream;
                var result = utility.UploadBlob(fileName, ContainerName, imageStream);
                if (result != null)
                {
                    string loggedInUserId = User.Identity.GetUserId();
                    Image userimage = new Image();
                    userimage.Id = new Random().Next().ToString();
                    userimage.UserId = loggedInUserId;
                    userimage.ImageUrl = result.Uri.ToString();
                    db.Images.Add(userimage);
                    db.SaveChanges();
                    return RedirectToAction("ImageUpload");
                }
                else
                {
                    return RedirectToAction("ImageUpload");
                }
            }
            else
            {
                return RedirectToAction("ImageUpload");
            }

        }
    }
}